const config = {
    apiUrl: 'https://curiotory-admin-backend-s4zy.onrender.com',
    // apiUrl: 'http://localhost:3000',
    // apiUrl: 'https://main.recrutory-apis.com:3100',
  };
  
  export default config;
  